package Main;
import int101.dummy.*;
public class int101h12 {
    public static void main(String[] args) {
        int loop =  10_000;
        double min =Double.MAX_VALUE;
        double max = Double.MIN_VALUE;
        for(int i = 0 ; i<loop ; i++){
            double r =dummy.rand();
            min= r<min?r:min;
            max= r>max?r:max;
            System.out.println(max +" "+ min    );
        }
    }
}
